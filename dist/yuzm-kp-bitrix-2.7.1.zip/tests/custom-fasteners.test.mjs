import {test} from 'node:test';
import assert from 'node:assert/strict';
import {calculateQuote,validateConfig,withCoatingOptions,formatCoating} from '../src/calculator.js';
import {newRow,newCustomRow} from '../src/demo.js';
import {assignFasteners} from '../src/fasteners.js';
import {BitrixAdapter,fingerprintRows} from '../src/bitrix.js';
const config=withCoatingOptions(validateConfig({currency:'RUB',rounding:'unit',coatings:[{code:'none',name:'Без покрытия'}]}));
const product={id:'11',name:'НФГ-6,0-05-ц',basePrice:1000,currency:'RUB',source:'catalog',isSupportSection:true,fastenerUnitPrice:500};
function goods(){const row=newRow(product);assignFasteners(row,product);return row;}
function custom(){return {...newCustomRow(),productName:'Монтаж по чертежу',basePrice:'250',quantity:'2'};}
test('fasteners are added once per unit before all coefficients and quantity',()=>{
 const row={...goods(),k1:'2',k2:'1,5',k3:'1,2',quantity:'3'};
 const result=calculateQuote([row],config);assert.equal(result.valid,true);assert.equal(result.rows[0].unitPrice,5400);assert.equal(result.total,16200);
 const off=calculateQuote([{...row,fastenersEnabled:false}],config);assert.equal(off.total,10800);
});
test('only section classification enables automatic addition; names do not affect the choice',()=>{
 const row=newRow(product);assignFasteners(row,{...product,name:'Любое изделие',isSupportSection:false});
 assert.equal(row.fastenersEnabled,false);assert.equal(calculateQuote([row],config).total,1000);
 const old=newRow(product);assert.equal(old.fastenersEnabled,false);assert.equal(calculateQuote([old],config).total,1000);
});
test('custom row requires name and explicit price, including explicit zero; all coefficients and quantity apply',()=>{
 let row=newCustomRow();assert.equal(calculateQuote([row],config).valid,false);
 row.productName='Своя позиция';assert.equal(calculateQuote([row],config).valid,false);
 row.basePrice='0';assert.equal(calculateQuote([row],config).valid,true);
 row={...row,basePrice:'125,50',quantity:'3',k1:'2',k2:'1,5',k3:'1,2'};
 assert.equal(calculateQuote([row],config).total,1355.4);
 assert.equal(calculateQuote([{...row,basePrice:'-1'}],config).valid,false);
});
test('custom coating text is required and exported as entered; retired excel formula is ignored',()=>{
 assert.throws(()=>formatCoating({code:'custom'}),/Нестандартное/);
 const row={...custom(),coatingCode:'custom',customCoating:'Двухслойное покрытие заказчика'};
 const result=calculateQuote([row],config);assert.equal(result.rows[0].coatingName,row.customCoating);
 assert.equal(calculateQuote([{...row,customCoating:''}],config).valid,false);
 assert.equal(validateConfig({...config,formulaMode:'excel'}).formulaMode,'catalog');
 assert.equal(calculateQuote([{...goods(),pricePerKg:900,weight:900}],{...config,formulaMode:'excel'}).total,1500);
});
function adapterFixture({failDocument=false}={}){
 const adapter=new BitrixAdapter(),calls=[];adapter.connected=true;
 let current=[{productId:'99',productName:'Прежний товар',unitPrice:20,quantity:1,taxRate:0,taxIncluded:'Y'}];
 adapter._documentDeal=async()=>({currency:'RUB',categoryId:'0'});
 adapter.loadDeal=async()=>({id:'55',currency:'RUB',rows:structuredClone(current)});
 adapter.getProduct=async(id)=>{calls.push({method:'GET_PRODUCT',id});assert.equal(String(id),'11');return {verified:true,currency:'RUB'};};
 adapter.call=async(method,params)=>{
  calls.push({method,params});
  if(method==='crm.documentgenerator.template.get')return {template:{id:3,name:'КП',active:'Y',isDeleted:'N',entityTypeId:['2']}};
  if(method==='crm.item.productrow.set') {current=params.productRows.map(r=>({productId:String(r.productId ?? 0),productName:r.productName,unitPrice:r.price,quantity:r.quantity,taxRate:r.taxRate,taxIncluded:r.taxIncluded}));return true;}
  if(method==='crm.documentgenerator.document.add'){
   if(failDocument)throw new Error('Generation failed');
   return {document:{id:77,templateId:3,entityId:55,entityTypeId:2,downloadUrl:'https://portal.example/doc.docx'}};
  }
  throw new Error(method);
 };
 return {adapter,calls,current:()=>current};
}
function snapshot(rows){const q=calculateQuote(rows,config);assert.equal(q.valid,true);return {...q,config,dealId:'55',companyName:'Заказчик',currency:'RUB',documentFields:{}};}
test('mixed quote transfers catalog and custom lines in order with the full DOCX total',async()=>{
 const {adapter,calls,current}=adapterFixture();const row={...custom(),coatingCode:'custom',customCoating:'Покрытие заказчика'};
 const q=snapshot([goods(),row]);assert.equal(q.total,2000);
 await adapter.createQuoteDocument(55,3,q,fingerprintRows(current()));
 assert.equal(current().length,2);assert.equal(current()[0].productId,'11');assert.equal(current()[0].unitPrice,1500);
 assert.equal(current()[1].productId,'0');assert.equal(current()[1].productName,row.productName);
 assert.equal(current()[1].unitPrice,250);assert.equal(current()[1].quantity,2);
 assert.equal(calls.filter(c=>c.method==='GET_PRODUCT').length,1);
 const doc=calls.find(c=>c.method==='crm.documentgenerator.document.add').params;
 assert.equal(doc.values.KpItems.length,2);assert.equal(doc.values.KpItems[1].Name,row.productName);assert.equal(doc.values.KpItems[1].Coating,row.customCoating);
 assert.equal(doc.fields.TotalSum.VALUE.replace(/\s/g,''),'2000,00');
});
test('custom-only quote replaces CRM goods without a catalog lookup or fabricated product ID',async()=>{
 const {adapter,calls,current}=adapterFixture();await adapter.createQuoteDocument(55,3,snapshot([custom()]),fingerprintRows(current()));
 assert.equal(current()[0].productId,'0');assert.ok(!calls.some(c=>c.method==='GET_PRODUCT'));
 const write=calls.find(c=>c.method==='crm.item.productrow.set').params;
 assert.equal(write.ownerType,'D');assert.equal(write.ownerId,55);
 assert.ok(!Object.hasOwn(write.productRows[0],'productId'));
 assert.equal(calls.find(c=>c.method==='crm.documentgenerator.document.add').params.values.KpItems.length,1);
});
test('failed custom-only document generation reports that CRM goods were already transferred',async()=>{
 const {adapter,current}=adapterFixture({failDocument:true});
 await assert.rejects(adapter.createQuoteDocument(55,3,snapshot([custom()]),fingerprintRows(current())),error=>error.goodsTransferred===true);
 assert.equal(current()[0].productId,'0');
});
test('explicit CRM transfer uses the full total and accepts custom-only payloads',async()=>{
 const {adapter,calls,current}=adapterFixture();const expected=fingerprintRows(current());
 const result=await adapter.applyToDeal(55,snapshot([goods(),custom()]),expected);assert.equal(result.total,2000);
 const customResult=await adapter.applyToDeal(55,snapshot([custom()]),fingerprintRows(current()));assert.equal(customResult.total,500);
 assert.equal(current().length,1);assert.equal(current()[0].productName,'Монтаж по чертежу');
});
test('catalog-only transfer keeps the catalog ID, calculated unit price, quantity and tax',async()=>{
 const {adapter,calls,current}=adapterFixture();
 const row={...goods(),quantity:'3',k1:'0,9',k2:'1,1',k3:'1,2',taxRate:20,taxIncluded:'Y'};
 const result=await adapter.applyToDeal(55,snapshot([row]),fingerprintRows(current()));
 assert.equal(result.total,5346);assert.equal(result.verified,true);
 const write=calls.find(c=>c.method==='crm.item.productrow.set').params;
 assert.equal(write.ownerType,'D');assert.equal(write.ownerId,55);
 assert.deepEqual(write.productRows[0],{productId:11,productName:row.productName,price:1782,quantity:3,discountTypeId:2,discountRate:0,discountSum:0,taxRate:20,taxIncluded:'Y',sort:10});
});
test('the custom bracket from the specification is written without a product ID and read back',async()=>{
 const {adapter,calls,current}=adapterFixture();let reads=0;
 const load=adapter.loadDeal;adapter.loadDeal=async()=>{reads++;return load();};
 const row={...custom(),productName:'Кронштейн 1.К2-2,0-2,0-/90-Ф3-ц',basePrice:'1835',quantity:'56',productId:'999'};
 const result=await adapter.applyToDeal(55,snapshot([row]),fingerprintRows(current()));
 const sent=calls.find(c=>c.method==='crm.item.productrow.set').params.productRows[0];
 assert.ok(!Object.hasOwn(sent,'productId'));assert.equal(sent.productName,row.productName);
 assert.equal(sent.price,1835);assert.equal(sent.quantity,56);assert.equal(result.total,102760);
 assert.equal(reads,2);assert.ok(!calls.some(c=>c.method==='GET_PRODUCT'));
});
test('interleaved catalog and custom rows retain their order, prices and complete total',async()=>{
 const {adapter,calls,current}=adapterFixture();
 const q=snapshot([{...custom(),productName:'Первая'},goods(),{...custom(),productName:'Третья',basePrice:100,quantity:'3'},goods()]);
 const result=await adapter.applyToDeal(55,q,fingerprintRows(current()));
 const sent=calls.find(c=>c.method==='crm.item.productrow.set').params.productRows;
 assert.deepEqual(sent.map(r=>r.sort),[10,20,30,40]);
 assert.deepEqual(sent.map(r=>r.productId),[undefined,11,undefined,11]);
 assert.deepEqual(current().map(r=>r.productName),q.rows.map(r=>r.productName));
 assert.equal(result.total,q.total);assert.equal(result.total,3800);
 assert.equal(calls.filter(c=>c.method==='GET_PRODUCT').length,1);
});
for(const scenario of ['manual','document']){
 test(`${scenario} transfer requires confirmation of existing goods`,async()=>{
  const {adapter,calls}=adapterFixture(),q=snapshot([custom()]);
  const action=scenario==='manual'?adapter.applyToDeal(55,q):adapter.createQuoteDocument(55,3,q);
  await assert.rejects(action,/подтверждение/);
  assert.ok(!calls.some(c=>c.method==='crm.item.productrow.set'||c.method==='crm.documentgenerator.document.add'));
 });
 test(`${scenario} transfer rejects stale confirmation without changing goods`,async()=>{
  const {adapter,calls,current}=adapterFixture(),q=snapshot([custom()]);
  const expected=fingerprintRows(current());current()[0].quantity=2;
  const action=scenario==='manual'?adapter.applyToDeal(55,q,expected):adapter.createQuoteDocument(55,3,q,expected);
  await assert.rejects(action,/изменились после/);
  assert.ok(!calls.some(c=>c.method==='crm.item.productrow.set'||c.method==='crm.documentgenerator.document.add'));
 });
}
test('an empty deal accepts custom rows and verifies the resulting composition',async()=>{
 const {adapter,current}=adapterFixture();current().splice(0);
 const result=await adapter.applyToDeal(55,snapshot([custom()]));assert.equal(result.verified,true);
 assert.equal(result.rows.length,1);
});
for(const [field,value] of [['productName','Другое имя'],['productId','11'],['unitPrice',999],['quantity',999]]){
 test(`custom-row readback detects an altered ${field} and does not create a document`,async()=>{
  const {adapter,calls,current}=adapterFixture();const call=adapter.call;
  adapter.call=async(method,params)=>{const result=await call(method,params);if(method==='crm.item.productrow.set')current()[0][field]=value;return result;};
  await assert.rejects(adapter.createQuoteDocument(55,3,snapshot([custom()]),fingerprintRows(current())),error=>error.code==='WRITE_UNVERIFIED');
  assert.equal(calls.filter(c=>c.method==='crm.item.productrow.set').length,1);
  assert.ok(!calls.some(c=>c.method==='crm.documentgenerator.document.add'));
 });
}
test('REST write errors retain their cause and do not trigger a second write or document generation',async()=>{
 const {adapter,calls,current}=adapterFixture();const call=adapter.call;
 adapter.call=async(method,params)=>{if(method==='crm.item.productrow.set') {calls.push({method,params});const error=new Error('METHOD_NOT_FOUND: crm.item.productrow.set');error.code='METHOD_NOT_FOUND';throw error;}return call(method,params);};
 await assert.rejects(adapter.createQuoteDocument(55,3,snapshot([custom()]),fingerprintRows(current())),/METHOD_NOT_FOUND/);
 assert.equal(current()[0].productId,'99');assert.equal(calls.filter(c=>c.method==='crm.item.productrow.set').length,1);
 assert.ok(!calls.some(c=>c.method==='crm.deal.productrows.set'||c.method==='crm.documentgenerator.document.add'));
});
test('custom rows retain rounding checks against the full quote total',async()=>{
 const {adapter,calls,current}=adapterFixture();const row={...custom(),basePrice:'0,01',k1:'1,4',quantity:'10'};
 const q=calculateQuote([row],{...config,rounding:'line'});assert.equal(q.total,0.14);
 await assert.rejects(adapter.applyToDeal(55,{...q,dealId:'55',currency:'RUB'},fingerprintRows(current())),/округление цены единицы/);
 assert.ok(!calls.some(c=>c.method==='crm.item.productrow.set'));
});
test('display prices batch visible IDs without per-product get and retain missing/zero distinction',async()=>{
 const adapter=new BitrixAdapter();adapter.connected=true;
 adapter._catalogRaw.set('11',{raw:{id:11,name:'Опора',iblockId:24},source:'catalog.product.list'});
 adapter._catalogRaw.set('12',{raw:{id:12,name:'Другой товар',iblockId:24},source:'catalog.product.list'});
 adapter._catalogRaw.set('13',{raw:{id:13,name:'Нулевая цена',price:0,currency:'RUB'},source:'catalog.product.list'});
 const requested=[];adapter._prices=async ids=>{requested.push(ids);return new Map([['11',{basePrice:1000,currency:'RUB'}]]);};
 const result=await adapter.getCatalogPrices(['11','12','13']);assert.deepEqual(requested,[['11','12']]);
 assert.equal(result[0].basePrice,1000);assert.equal(result[0].priceMissing,false);assert.equal(result[1].priceMissing,true);
 assert.equal(result[2].basePrice,0);assert.equal(result[2].priceMissing,false);
 await assert.rejects(adapter.getCatalogPrices(Array.from({length:51},(_,i)=>i+1)),/до 50/);
});

